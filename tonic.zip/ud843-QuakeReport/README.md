tonic app
===================================

Android app (Java) to learn networking in Android.
Displays earthquake information by consuming: 

- https://earthquake.usgs.gov/fdsnws/event/1/

Pre-requisites
--------------

- Android SDK v23
- Android Build Tools v23.0.2
- Android Support Repository v23.3.0
